#!/usr/bin/env bash
set -euo pipefail

SOURCE="${1:-}"
BASE="http://127.0.0.1:3008"
DIR="$(dirname "$0")"
MAX_POLLS="${PAPERBOT_MAX_POLLS:-72}"
POLL_SECONDS="${PAPERBOT_POLL_SECONDS:-5}"

if [ -z "$SOURCE" ]; then
  echo "请提供微信公众号链接或完整论文题目"
  exit 2
fi

if [ "${#SOURCE}" -gt 2000 ]; then
  echo "提交失败：链接或论文题目过长"
  exit 2
fi

if [ ! -r "$DIR/secret" ]; then
  echo "登录失败：PaperBot 技能凭据文件不存在或不可读"
  exit 1
fi

USER="$(sed -n '1p' "$DIR/secret")"
PASS="$(sed -n '2p' "$DIR/secret")"
if [ -z "$USER" ] || [ -z "$PASS" ]; then
  echo "登录失败：PaperBot 技能凭据不完整"
  exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
COOKIE_JAR="$TMP_DIR/cookies.txt"
CURL=(curl --silent --show-error --fail-with-body --connect-timeout 5 --max-time 30)

LOGIN_JSON="$(node -e 'process.stdout.write(JSON.stringify({username:process.argv[1],password:process.argv[2]}))' "$USER" "$PASS")"
if ! LOGIN_RESP="$("${CURL[@]}" --cookie-jar "$COOKIE_JAR" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' --data-binary "$LOGIN_JSON" 2>&1)"; then
  echo "登录失败：${LOGIN_RESP:0:300}"
  exit 1
fi
if [ ! -s "$COOKIE_JAR" ]; then
  echo "登录失败：服务器未返回登录会话"
  exit 1
fi
AUTH=(--cookie "$COOKIE_JAR")

ADD_JSON="$(node -e 'process.stdout.write(JSON.stringify({url:process.argv[1]}))' "$SOURCE")"
if ! ADD_RESP="$("${CURL[@]}" "${AUTH[@]}" -X POST "$BASE/api/add" -H 'Content-Type: application/json' --data-binary "$ADD_JSON" 2>&1)"; then
  echo "提交失败：${ADD_RESP:0:300}"
  exit 1
fi

TARGET="$(printf '%s' "$ADD_RESP" | node -e '
let d="";
process.stdin.on("data",c=>d+=c).on("end",()=>{
  try {
    const r=JSON.parse(d), j=Array.isArray(r.jobs)?r.jobs[0]:null;
    if(!r.ok || !j) throw new Error(r.error||"服务器没有返回任务信息");
    if(j.item_id) return console.log("item:"+j.item_id);
    if(j.id) return console.log("job:"+j.id);
    throw new Error("任务缺少编号");
  } catch(e) {
    console.error(String(e.message||e));
    process.exit(1);
  }
})' 2>"$TMP_DIR/add-error.txt")" || {
  echo "提交失败：$(cat "$TMP_DIR/add-error.txt")"
  exit 1
}

echo "已提交到 PaperBot，正在等待同一套网页解析流程完成……"

ITEM_ID=""
if [[ "$TARGET" == item:* ]]; then
  ITEM_ID="${TARGET#item:}"
else
  JOB_ID="${TARGET#job:}"
  for ((i=1; i<=MAX_POLLS; i++)); do
    if ! JOB_RESP="$("${CURL[@]}" "${AUTH[@]}" "$BASE/api/job/$JOB_ID" 2>&1)"; then
      echo "查询任务失败：${JOB_RESP:0:300}"
      exit 1
    fi
    STATE="$(printf '%s' "$JOB_RESP" | node -e '
let d="";
process.stdin.on("data",c=>d+=c).on("end",()=>{
  try {
    const j=JSON.parse(d);
    if(j.status==="done" && j.item_id) return console.log("done:"+j.item_id);
    if(j.status==="error") return console.log("error:"+(j.error||"未知错误").replace(/[\r\n]+/g," "));
    console.log(j.status||"unknown");
  } catch(e) { console.log("invalid"); }
})')"
    if [[ "$STATE" == done:* ]]; then
      ITEM_ID="${STATE#done:}"
      break
    fi
    if [[ "$STATE" == error:* ]]; then
      echo "解析失败：${STATE#error:}"
      exit 1
    fi
    if [ "$STATE" = "invalid" ] || [ "$STATE" = "unknown" ]; then
      echo "查询任务失败：服务器返回异常"
      exit 1
    fi
    sleep "$POLL_SECONDS"
  done
fi

if [ -z "$ITEM_ID" ]; then
  echo "等待超时：PaperBot 仍在处理任务，可稍后到网页查看或重试"
  exit 1
fi

"${CURL[@]}" "${AUTH[@]}" "$BASE/api/item/$ITEM_ID" | node -e '
let d="";
process.stdin.on("data",c=>d+=c).on("end",()=>{
  let it;
  try { it=JSON.parse(d); } catch(e) {
    console.log("解析失败："+d.slice(0,200));
    process.exit(1);
  }
  if(!it || it.error) {
    console.log("没有找到解析结果");
    process.exit(1);
  }
  const fields=[
    ["记录ID",it.id],
    ["标题",it.title||it.wxtitle],
    ["中文标题",it.title_cn],
    ["期刊",it.journal],
    ["发表时间",it.accepted_date?"Accepted "+it.accepted_date:it.pubdate],
    ["第一作者",it.first_author],
    ["通讯作者",it.corresponding_authors],
    ["所属机构",it.affiliations],
    ["PMID",it.pmid],
    ["DOI",it.doi],
    ["关键词",it.keywords],
    ["总结",it.summary],
    ["结论",it.conclusion],
    ["研究背景",it.research_background],
    ["核心突破",it.core_breakthrough],
    ["技术创新",it.technical_innovation],
    ["关键结果",it.key_results],
    ["应用前景",it.applications],
    ["未来展望",it.future_outlook],
    ["生信视角",it.bioinformatics],
    ["方法学借鉴与生信思考",it.methodological_insight],
    ["肝癌相关研究现状",it.liver_cancer_assessment],
    ["迁移到肝癌的研究设计",it.liver_cancer_design],
    ["创新空间与撞题风险",it.liver_cancer_novelty]
  ];
  for(const [name,value] of fields) {
    if(value!==null && value!==undefined && String(value).trim()) {
      console.log("\n【"+name+"】\n"+String(value).trim());
    }
  }
});
'
