const express = require('express');
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');

function loadConfig() {
  const defaults = {
    DEEPSEEK_API_KEY: '',
    DEEPSEEK_BASE_URL: 'https://api.deepseek.com',
    DEEPSEEK_MODEL: 'deepseek-chat',
    PORT: 3008,
    PASSWORD: ''
  };
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'));
    return Object.assign(defaults, cfg);
  } catch (e) {
    return defaults;
  }
}

const CONFIG = loadConfig();
const PORT = process.env.PORT || CONFIG.PORT || 3008;

const db = new DatabaseSync(path.join(__dirname, 'data.db'));
db.exec(`
  CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    url TEXT UNIQUE,
    wxtitle TEXT,
    wx_pubtime TEXT,
    pmid TEXT,
    doi TEXT,
    journal TEXT,
    pubdate TEXT,
    title TEXT,
    keywords TEXT,
    summary TEXT,
    conclusion TEXT,
    created_at TEXT
  )
`);
try { db.exec("ALTER TABLE items ADD COLUMN wx_pubtime TEXT"); } catch (e) {}

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';

async function getText(url) {
  const res = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept': 'text/html,application/xhtml+xml,application/json,text/plain,*/*',
      'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
    }
  });
  if (!res.ok) throw new Error('请求失败 HTTP ' + res.status);
  return await res.text();
}

async function getJson(url) {
  const res = await fetch(url, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error('请求失败 HTTP ' + res.status);
  return await res.json();
}

function decodeEntities(s) {
  return s
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(Number(n)));
}

function stripTags(html) {
  return decodeEntities(
    html
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, '\n')
      .replace(/<\/p>/gi, '\n')
      .replace(/<[^>]+>/g, ' ')
  ).replace(/[ \t\u00a0]+/g, ' ').replace(/\n{2,}/g, '\n').trim();
}

function getMeta(html, key) {
  const re = new RegExp('<meta[^>]+(?:property|name)=["\']' + key + '["\'][^>]*>', 'i');
  const m = html.match(re);
  if (!m) return '';
  const c = m[0].match(/content=["\']([\s\S]*?)["\']/i);
  return c ? decodeEntities(c[1]) : '';
}

function extractWxTime(html) {
  let m = html.match(/var\s+ct\s*=\s*["']?(\d{10})/);
  if (!m) m = html.match(/["']?create_time["']?\s*[:=]\s*["']?(\d{10})/);
  if (m) {
    const d = new Date(Number(m[1]) * 1000);
    if (!isNaN(d.getTime())) return d.toISOString().slice(0, 10);
  }
  return '';
}

function extractArticle(html) {
  let title = getMeta(html, 'og:title');
  if (!title) {
    const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    if (m) title = stripTags(m[1]);
  }
  if (!title) {
    const m = html.match(/<title>([\s\S]*?)<\/title>/i);
    if (m) title = stripTags(m[1]);
  }

  let text = '';
  const idx = html.search(/id=["']js_content["']/i);
  if (idx >= 0) {
    let chunk = html.slice(idx);
    const end = chunk.search(/<script/i);
    if (end > 0) chunk = chunk.slice(0, end);
    text = stripTags(chunk);
  } else {
    text = stripTags(html);
  }
  return { title: title.trim(), text, pubtime: extractWxTime(html) };
}

function findIdentifiers(text) {
  const doiSet = new Set();
  const doiRe = /10\.\d{4,9}\/[^\s"'<>()\[\]]+/g;
  let m;
  while ((m = doiRe.exec(text)) !== null) {
    doiSet.add(m[0].replace(/[.,;:]+$/, ''));
  }
  const pmidSet = new Set();
  const pmidRe = /PMID[:\s]*([0-9]{6,9})/gi;
  while ((m = pmidRe.exec(text)) !== null) {
    pmidSet.add(m[1]);
  }
  return { dois: [...doiSet], pmids: [...pmidSet] };
}

async function pubsByDoi(doi) {
  const url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=3&term=' +
    encodeURIComponent(doi + '[DOI]');
  const j = await getJson(url);
  return (j.esearchresult && j.esearchresult.idlist) || [];
}

async function pubsByTitleTerm(term) {
  const url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?db=pubmed&retmode=json&retmax=3&term=' +
    encodeURIComponent(term);
  const j = await getJson(url);
  return (j.esearchresult && j.esearchresult.idlist) || [];
}

async function fetchPubmed(id) {
  const url = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?db=pubmed&id=' +
    encodeURIComponent(id) + '&rettype=abstract&retmode=text';
  return await getText(url);
}

function parsePubmed(txt) {
  const journalM = txt.match(/^\d+\.\s*([^.]+)\.\s*(\d{4}[^;]*);/m);
  const doiM = txt.match(/doi:\s*([^\s.]+(?:\.[^\s]+)*)/i);
  const pmidM = txt.match(/PMID:\s*(\d+)/i);
  const dateM = txt.match(/^\d+\.\s*[^.]+\.\s*([0-9]{4}\s+[A-Za-z]{3}(?:\s+\d{1,2})?);/m);
  let title = '';
  const titleM = txt.match(/^\d+\.[^\n]*\n([\s\S]*?)\n\n/m);
  if (titleM) title = titleM[1].replace(/\s*\n\s*/g, ' ').trim().replace(/\.$/, '');
  return {
    journal: journalM ? journalM[1].trim() : '',
    doi: doiM ? doiM[1] : '',
    pmid: pmidM ? pmidM[1] : '',
    pubdate: dateM ? dateM[1] : '',
    title: title,
    raw: txt
  };
}

async function deepseekJson(prompt) {
  const res = await fetch(CONFIG.DEEPSEEK_BASE_URL + '/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + CONFIG.DEEPSEEK_API_KEY
    },
    body: JSON.stringify({
      model: CONFIG.DEEPSEEK_MODEL,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.2,
      response_format: { type: 'json_object' }
    })
  });
  if (!res.ok) throw new Error('DeepSeek HTTP ' + res.status);
  const j = await res.json();
  const content = (j.choices && j.choices[0] && j.choices[0].message.content) || '{}';
  return JSON.parse(content);
}

async function identifyPaper(text) {
  if (!CONFIG.DEEPSEEK_API_KEY) return null;
  const prompt = '判断下面这篇公众号文章主要介绍的是哪一篇科研论文。只输出 JSON，不要多余文字：' +
    '{"single":true或false,"title":"论文英文标题","doi":"DOI(文中明确写了才填,否则空)","pmid":"PMID(明确写了才填,否则空)",' +
    '"journal":"期刊英文名(文中提到才填,否则空)","year":"发表年份4位(文中提到才填,否则空)"}。' +
    '如果它只是行业综述/多个成果合集、没有单一主论文，则 single=false，title 填文章最主要的那个成果。\n\n文章：\n' +
    text.slice(0, 9000);
  try {
    const r = await deepseekJson(prompt);
    return {
      single: r.single !== false,
      title: (r.title || '').trim(),
      doi: (r.doi || '').trim().replace(/[.,;]+$/, ''),
      pmid: (r.pmid || '').trim(),
      journal: (r.journal || '').trim(),
      year: (r.year || '').trim().replace(/[^0-9]/g, '').slice(0, 4)
    };
  } catch (e) {
    return null;
  }
}

async function searchPmidByTitle(title, journal, year) {
  const tries = [];
  if (journal && year) tries.push(title + ' AND ' + journal + '[ta] AND ' + year + '[dp]');
  if (journal) tries.push(title + ' AND ' + journal + '[ta]');
  if (year) tries.push(title + ' AND ' + year + '[dp]');
  tries.push(title + '[Title]');
  tries.push(title);
  for (const term of tries) {
    try {
      const hits = await pubsByTitleTerm(term);
      if (hits.length) return hits[0];
    } catch (e) {}
  }
  return '';
}

async function summarize(text) {
  if (!CONFIG.DEEPSEEK_API_KEY) {
    return { keywords: '', summary: '(未配置 DeepSeek API Key，仅抓取到原文)', conclusion: '' };
  }
  const prompt = '你是科研编辑。根据下面内容，只输出一个 JSON（不要多余文字）：' +
    '{"keywords":"5个中文关键词，用逗号分隔","pubdate":"论文发表日期(如 2024-12-12)，没有则空",' +
    '"summary":"不超过200字的中文总结，覆盖研究背景/方法/结论，通俗精炼","conclusion":"一句话结论"}。\n\n内容：\n' +
    text.slice(0, 9000);
  return await deepseekJson(prompt);
}

async function processUrl(url) {
  const html = await getText(url);
  const article = extractArticle(html);
  const ids = findIdentifiers(article.text);

  let pmid = ids.pmids[0] || '';
  let pubText = '';
  let mainTitle = '';

  if (!pmid) {
    const idn = await identifyPaper(article.text);
    if (idn) {
      mainTitle = idn.title || '';
      if (idn.pmid) pmid = idn.pmid;
      if (!pmid && idn.doi) {
        try { const hits = await pubsByDoi(idn.doi); if (hits.length) pmid = hits[0]; } catch (e) {}
      }
      if (!pmid && idn.title) {
        pmid = await searchPmidByTitle(idn.title, idn.journal, idn.year);
      }
    }
  }
  if (!pmid) {
    for (const doi of ids.dois.slice(0, 5)) {
      try {
        const hits = await pubsByDoi(doi);
        if (hits.length) { pmid = hits[0]; break; }
      } catch (e) {}
    }
  }
  if (!pmid && (mainTitle || article.title)) {
    const t = mainTitle || article.title;
    pmid = await searchPmidByTitle(t.replace(/[【】\[\]|]/g, ' '), '', '');
  }

  let meta = { journal: '', doi: ids.dois[0] || '', pmid, pubdate: '', title: '', raw: '' };
  if (pmid) {
    pubText = await fetchPubmed(pmid);
    meta = parsePubmed(pubText);
    meta.pmid = pmid;
  }

  const sourceForLLM = (article.text ? ('【公众号内容】\n' + article.text + '\n\n') : '') +
    (pubText ? ('【PubMed 摘要】\n' + pubText) : '');
  const sum = await summarize(sourceForLLM);

  const rec = {
    url,
    wxtitle: article.title,
    wx_pubtime: article.pubtime || '',
    pmid: meta.pmid || '',
    doi: meta.doi || '',
    journal: meta.journal || '',
    pubdate: meta.pubdate || sum.pubdate || '',
    title: meta.title || mainTitle || article.title || '',
    keywords: sum.keywords || '',
    summary: sum.summary || '',
    conclusion: sum.conclusion || '',
    created_at: new Date().toISOString()
  };

  db.prepare(`INSERT INTO items
    (url,wxtitle,wx_pubtime,pmid,doi,journal,pubdate,title,keywords,summary,conclusion,created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    rec.url, rec.wxtitle, rec.wx_pubtime, rec.pmid, rec.doi, rec.journal, rec.pubdate,
    rec.title, rec.keywords, rec.summary, rec.conclusion, rec.created_at
  );
  return rec;
}

const jobs = [];
let running = false;

function enqueue(urls) {
  let n = 0;
  for (const u of urls) {
    if (jobs.some(j => j.url === u && j.status !== 'done')) continue;
    jobs.push({ url: u, status: 'pending', ts: Date.now() });
    n++;
  }
  if (n) pump();
  return n;
}

async function pump() {
  if (running) return;
  running = true;
  while (true) {
    const job = jobs.find(j => j.status === 'pending');
    if (!job) break;
    job.status = 'running';
    try {
      await processUrl(job.url);
      job.status = 'done';
    } catch (e) {
      job.status = 'error';
      job.error = String((e && e.message) || e);
    }
    job.ts = Date.now();
  }
  running = false;
}

const app = express();
app.use(express.json());

function auth(req, res, next) {
  if (!CONFIG.PASSWORD) return next();
  const h = req.headers.authorization || '';
  if (h.startsWith('Basic ')) {
    let dec = '';
    try { dec = Buffer.from(h.slice(6), 'base64').toString('utf8'); } catch (e) {}
    const i = dec.indexOf(':');
    const pass = i >= 0 ? dec.slice(i + 1) : dec;
    if (pass === CONFIG.PASSWORD) return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="paper-bot"');
  return res.status(401).send('需要密码');
}
app.use(auth);

app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/add', (req, res) => {
  const url = ((req.body && req.body.url) || '').trim();
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ error: '请提供有效的链接' });
  res.json({ ok: true, queued: enqueue([url]) });
});

app.post('/api/add-many', (req, res) => {
  const list = ((req.body && req.body.urls) || []).map(s => String(s).trim()).filter(u => /^https?:\/\//i.test(u));
  if (!list.length) return res.status(400).json({ error: '没有检测到有效链接' });
  res.json({ ok: true, queued: enqueue(list) });
});

app.get('/api/queue', (req, res) => {
  res.json({
    running,
    pending: jobs.filter(j => j.status === 'pending').length,
    active: jobs.filter(j => j.status === 'running').length,
    recent: jobs.slice(-30).map(j => ({ url: j.url, status: j.status, error: j.error || '' }))
  });
});

app.get('/api/list', (req, res) => {
  const q = (req.query.q || '').toString().trim();
  let rows;
  if (q) {
    rows = db.prepare('SELECT * FROM items WHERE title LIKE ? OR wxtitle LIKE ? OR keywords LIKE ? OR journal LIKE ? ORDER BY id DESC')
      .all('%' + q + '%', '%' + q + '%', '%' + q + '%', '%' + q + '%');
  } else {
    rows = db.prepare('SELECT * FROM items ORDER BY id DESC').all();
  }
  res.json(rows);
});

app.delete('/api/item/:id', (req, res) => {
  db.prepare('DELETE FROM items WHERE id = ?').run(Number(req.params.id));
  res.json({ ok: true });
});

app.get('/api/export', (req, res) => {
  const rows = db.prepare('SELECT * FROM items ORDER BY id DESC').all();
  let md = '# 论文总结汇总\n\n共 ' + rows.length + ' 条\n\n';
  for (const r of rows) {
    md += '## ' + (r.title || r.wxtitle || '(无标题)') + '\n\n';
    md += '- 发表时间：' + (r.pubdate || '') + '\n';
    if (r.wx_pubtime) md += '- 公众号发布：' + r.wx_pubtime + '\n';
    md += '- 期刊：' + (r.journal || '') + '\n';
    md += '- PMID：' + (r.pmid || '') + '\n';
    md += '- DOI：' + (r.doi || '') + '\n';
    md += '- 关键词：' + (r.keywords || '') + '\n';
    md += '- 原文：' + r.url + '\n\n';
    md += (r.summary || '') + '\n\n';
    if (r.conclusion) md += '**结论：** ' + r.conclusion + '\n\n';
    md += '---\n\n';
  }
  res.set('Content-Type', 'text/markdown; charset=utf-8');
  res.set('Content-Disposition', 'attachment; filename="papers.md"');
  res.send(md);
});

app.listen(PORT, () => {
  console.log('paper-bot 已启动: http://localhost:' + PORT);
  console.log('DeepSeek Key: ' + (CONFIG.DEEPSEEK_API_KEY ? '已配置' : '未配置') + ' | 访问密码: ' + (CONFIG.PASSWORD ? '已设置' : '未设置'));
});
