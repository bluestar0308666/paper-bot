# Paper Bot · 公众号 → 论文 → 总结

把一篇微信公众号文章链接丢进来，自动：

1. 抓取公众号正文（含公众号发布时间）
2. 用大模型判断文章主讲哪篇论文（标题 / DOI / PMID / 期刊 / 年份）
3. 去 PubMed 精确匹配（PMID → DOI → 标题+期刊+年份 过滤）
4. 抓 PubMed 摘要，连同公众号正文一起交给大模型
5. 输出：关键词 / 论文发表日期 / ≤200字中文总结 / 一句话结论
6. 找不到对应论文时，直接总结公众号内容

## 技术栈
- Node.js（Termux 里 v24）+ Express + 内置 `node:sqlite`（免编译）
- 大模型：DeepSeek（OpenAI 兼容接口）
- 数据源：PubMed E-utilities

## 功能
- 网页端：批量粘贴链接、列表展示、搜索、删除、**导出 Markdown**
- 访问密码（Basic Auth）
- 后台队列：一次多条，逐条处理
- 外网访问：`ssh -R` 隧道（tunnel.sh，断线自动重连）

## 部署（云手机 Termux）
```bash
cd ~/pubmed
bash install.sh          # 装依赖、填配置、启动、设自启
bash tunnel.sh           # 开外网隧道，会打印公网网址
```

## 配置 `config.json`
```json
{
  "DEEPSEEK_API_KEY": "sk-...",
  "DEEPSEEK_BASE_URL": "https://api.deepseek.com",
  "DEEPSEEK_MODEL": "deepseek-chat",
  "PORT": 3008,
  "PASSWORD": "你的访问密码"
}
```

## 接口
- `POST /api/add` `{url}`
- `POST /api/add-many` `{urls:[...]}`
- `GET /api/queue` 队列状态
- `GET /api/list?q=` 列表/搜索
- `DELETE /api/item/:id`
- `GET /api/export` 导出 Markdown
