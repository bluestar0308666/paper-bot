#!/bin/bash
# ============================================
#  Paper Bot 一键安装 (Termux)
#  用法: bash ~/pubmed/install.sh
# ============================================
cd ~/pubmed || { echo "请先把代码放到 ~/pubmed"; exit 1; }

if [ ! -f config.json ]; then
  echo "首次配置（直接回车用默认）"
  read -p "DeepSeek API Key: " DK
  read -p "访问密码（自己设一个）: " PW
  cat > config.json <<EOF
{"DEEPSEEK_API_KEY":"$DK","DEEPSEEK_BASE_URL":"https://api.deepseek.com","DEEPSEEK_MODEL":"deepseek-chat","PORT":3008,"PASSWORD":"$PW"}
EOF
  echo "已生成 config.json"
fi

echo "[1/4] 安装依赖..."
npm install --omit=dev --no-audit --no-fund --registry=https://registry.npmmirror.com >/dev/null 2>&1 && echo "  完成" || echo "  有问题"

echo "[2/4] 重启服务..."
pkill -f "pubmed/server.js" 2>/dev/null || true
sleep 1
nohup node server.js > server.log 2>&1 &
sleep 2
curl -s -o /dev/null -w "  本地状态: HTTP %{http_code}\n" http://localhost:3008/api/list

echo "[3/4] 设置服务开机自启..."
SVC='if ! pgrep -f "pubmed/server.js" >/dev/null 2>&1; then cd ~/pubmed && nohup node server.js > server.log 2>&1 & fi'
grep -q "pubmed/server.js" ~/.bashrc 2>/dev/null || echo "$SVC" >> ~/.bashrc

echo "[4/4] 设置隧道开机自启..."
TUN='if ! pgrep -f "localhost.run" >/dev/null 2>&1; then cd ~/pubmed && nohup bash tunnel.sh > /dev/null 2>&1 & fi'
grep -q "tunnel.sh" ~/.bashrc 2>/dev/null || echo "$TUN" >> ~/.bashrc

echo ""
echo "======================================"
echo "  完成！"
echo "  1) 开隧道（前台运行，会显示公网网址）:"
echo "       cd ~/pubmed && bash tunnel.sh"
echo "  2) 浏览器打开打印出来的 https://xxx.lhr.life"
echo "  3) 用户名随便填，密码=你刚设的访问密码"
echo "======================================"
