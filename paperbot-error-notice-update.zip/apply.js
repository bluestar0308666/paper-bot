// Apply only the failed-job notice update to the existing PaperBot homepage.
// The bundled index.html is a source of the new notice code, not a replacement
// for the customized production homepage.
const fs = require('node:fs');
const path = require('node:path');

const target = process.env.PAPERBOT_INDEX_PATH || '/opt/paper-bot/public/index.html';
const source = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const current = fs.readFileSync(target, 'utf8');

if (current.includes('function dismissError(')) {
  console.log('失败提示更新已安装，无需重复执行。');
  process.exit(0);
}

const declarations = source.match(/const errorTimers=new Map\(\),dismissedErrors=new Set\(\);[\s\S]*?(?=const esc=)/)?.[0];
const logic = source.match(/function dismissError\(id\)[\s\S]*?(?=\$\('#go'\)\.onclick)/)?.[0];
const oldPoll = /async function poll\(\)\{[\s\S]*?(?=\$\('#go'\)\.onclick)/;
if (!declarations || !logic || !oldPoll.test(current) || !current.includes('</style>')) {
  throw new Error('页面结构不符合预期，未修改任何文件。');
}

const css = '.error .card-top{display:flex;align-items:flex-start;gap:16px;justify-content:space-between}.error .error-content{min-width:0;flex:1}.error .error-message{overflow-wrap:anywhere;word-break:break-word;white-space:pre-wrap;max-height:7em;overflow:auto}.error .error-actions{display:flex;gap:6px;flex:0 0 auto}.error .close-error{font-size:20px;line-height:1;padding:4px 8px}.error-archive{font-size:12px;color:var(--danger);margin:2px 0 10px}.error-archive button{font-size:12px;padding:5px 8px;background:#fbeeee;color:var(--danger)}@media(max-width:640px){.error .error-actions{flex-direction:column-reverse;align-items:flex-end}}';
let updated = current.replace('</style>', css + '</style>');
updated = updated.replace(oldPoll, declarations + logic);
const script = updated.match(/<script>([\s\S]*?)<\/script>/)?.[1];
if (!script) throw new Error('找不到首页脚本，未修改任何文件。');
new Function(script);

const backup = target + '.before-error-notice-' + new Date().toISOString().replace(/[:.]/g, '-') + '.bak';
fs.copyFileSync(target, backup);
fs.writeFileSync(target, updated);
console.log('首页失败提示已更新。备份：' + backup);
